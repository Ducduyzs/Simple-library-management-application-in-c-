﻿using System;

namespace MyLibrary_1
{
    internal class User
    {
        private string id;
        private string name;
        private string email;
        private string borrowedBooksID;

        public string _id
        {
            get { return id; }
            set { id = value; }
        }
        public string _name
        {
            get { return name; }
            set { name = value; }
        }
        public string _email
        { 
            get { return email; }
            set { email = value; }
        }
        public string _borrowedBooksID
        {
            get { return borrowedBooksID; }
            set { borrowedBooksID = value; }
        }

        public User(string id, string name, string email, string borrowedBooksID)
        {
            this._id= id;
            this._name = name;
            this._email = email;
            this._borrowedBooksID = borrowedBooksID;
        }

    }
}
