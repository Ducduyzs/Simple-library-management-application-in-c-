﻿using System;
using System.Collections.Generic;


namespace MyLibrary_1
{
    internal interface IUserManager
    {
        // Add User
        bool InsertUser(User user);

        // Delete User
        bool DeleteUser(string userID);

        // Search User With ID User
        List<User> SearchUserWithUserID(string userID);

        // Search User With Name User 
        List<User> SearchUserWithNameUser(string userName);
    }
}
