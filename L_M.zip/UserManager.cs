using System;
using System.Collections.Generic;
using System.Linq;

namespace MyLibrary_1
{
    internal class UserManager : IUserManager
    {
        // User List
        public static List<User> Users = new List<User>();

        //Borrow Book
        public bool BorrowBook(string userID, string bookID)
        {
            var user = Users.FirstOrDefault(u=>u._id==userID);
            if(user == null)
            {
                Console.WriteLine("User not found!");
                return false;
            }
            if(!string.IsNullOrEmpty(user._borrowedBooksID))
            {
                Console.WriteLine("User has already borrowed a book.");
                return false;
            }

            var book = BookManager.bookList.FirstOrDefault(b=>b._id == bookID & b._isAvailable);
            if(book == null)
            {
                Console.WriteLine("Book is either not available or not found.");
                return false;
            }

            book._isAvailable = false;
            BookManager.borowedList.Add(book);

            user._borrowedBooksID = bookID;

            Console.WriteLine($"Book {book._name} has been successfully borrowed by {user._name}.");
            return true;
        }
        public bool DeleteBorrowedBook(string bookID)
        {
            try
            {
                var borrowedBook = BookManager.borowedList.FirstOrDefault(book => book._id == bookID);
                if (borrowedBook == null)
                {
                    Console.WriteLine("Borrowed book not found.");
                    return false;
                }
                var user = Users.FirstOrDefault(u => u._borrowedBooksID == bookID);
                if (user != null)
                {
                    user._borrowedBooksID = null;
                }
                borrowedBook._isAvailable = true;
                BookManager.borowedList.Remove(borrowedBook);

                Console.WriteLine($"Borrowed book '{borrowedBook._name}' has been successfully deleted and marked as available.");
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
                return false;
            }
        }
        //Return Book 
        public bool ReturnBook(string userID)
        {
            var user = Users.FirstOrDefault(u => u._id == userID);
            if (user == null)
            {
                Console.WriteLine("User not found!");
                return false;
            }
            
            if(string.IsNullOrEmpty(user._borrowedBooksID))
            {
                Console.WriteLine("User has no borrowed book.");
                return false;
            }

            var borrowedBook = BookManager.borowedList.FirstOrDefault(b=> b._id == user._borrowedBooksID);
            if (borrowedBook == null)
            {
                Console.WriteLine("Borrow book not found.");
                return false;
            }

            borrowedBook._isAvailable = true;
            BookManager.bookList.Add(borrowedBook);
            BookManager.borowedList.Remove(borrowedBook);
            user._borrowedBooksID = "";

            Console.WriteLine($"Book {borrowedBook._name} has been successfully returned by {user._name}.");
            return true;

        }
        // Delete User
        public bool DeleteUser(string userID)
        {
            try
            {
                foreach (var i in Users)
                {
                    if (i._id == userID)
                    {
                        foreach (var j in BookManager.borowedList)
                        {
                            if (i._borrowedBooksID == j._id)
                            {
                                j._isAvailable = true;
                            }
                        }
                        Users.Remove(i);
                        return true;
                    }
                }
                return false;
            }
            catch (Exception)
            {

                throw;
            }
        }

        // Get Details User
        public bool InsertUser(User user)
        {
            try
            {
                Users.Add(user);
                return true;
            }
            catch (Exception)
            {
                return false;
                throw;
            }
        }

        // Search User With Name User
        public List<User> SearchUserWithNameUser(string userName)
        {
            try
            {
                List<User> u = new List<User>();
                foreach (var i in Users)
                {
                    if (i._name == userName)
                    {
                        u.Add(i);
                    }
                }
                return u;
            }
            catch (Exception)
            {
                return null;
                throw;
            }
        }

        // Search User With ID User
        public List<User> SearchUserWithUserID(string userID)
        {
            List<User> list = new List<User>();
            foreach (User i in Users)
            {
                if (i._id == userID)
                    list.Add(i);
            }
            return list;
        }
    }
}
