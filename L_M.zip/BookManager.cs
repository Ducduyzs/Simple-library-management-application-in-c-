﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Policy;

namespace MyLibrary_1
{
    internal class BookManager : IBookManager
    {
        
        //Book List
        public static List<Book> bookList = new List<Book>();
        public static List<Book> borowedList = new List<Book>();
        //Add Book
        public bool InsertBook(Book book)
        {
            try
            {
                bookList.Add(book);
                return true;
            }
            catch (Exception ex) 
            {
                Console.WriteLine($"Error: {ex.Message}");
                return false; 
            }
        }
        public bool DeleteBook(string bookID)
        {
            try
            {
                var bookToRemove = bookList.FirstOrDefault(book => book._id == bookID);
                
                var borrowedBook = BookManager.borowedList.FirstOrDefault(book => book._id == bookID);

                if (bookToRemove != null)
                {
                    bookList.Remove(bookToRemove);
                    Console.WriteLine($"Book with ID {bookID} has been successfully removed.");
                    return true;
                }
                else
                {
                    Console.WriteLine("Book not found.");
                    return false;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
                return false;
            }
        }
        

        //Search Book With ID Book
        public List<Book> SearchBookWithBookID(string bookID)
        {
            List<Book> list = new List<Book>();
            foreach (Book i in bookList)
            {
                if (i._id == bookID)
                    list.Add(i);
            }
            return list;
        }

        // Search Book With Book Name
        public List<Book> SearchBookWithBookName(string bookName)
        {
            List<Book> list = new List<Book>();
            foreach (Book i in bookList)
            {
                if (!string.IsNullOrEmpty(i._name) &&
                    i._name.IndexOf(bookName, StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    list.Add(i);
                }
            }
            return list;
        }




    }
}
