﻿using System;
using System.Collections.Generic;
using System.IO;

namespace MyLibrary_1
{
    internal class Program
    {
        public static string bookFilePath = @"D:\1.DH\Object-Oriented Programming\Project\6_12\LibraryManagement (1)\MyLibrary_1\Book\Book.txt";
        public static string userFilePath = @"D:\1.DH\Object-Oriented Programming\Project\6_12\LibraryManagement (1)\MyLibrary_1\User\User.txt";
        public static string borrowbookFilePath = @"D:\1.DH\Object-Oriented Programming\Project\6_12\LibraryManagement (1)\MyLibrary_1\Book\Bookborrow.txt";
        public static void Main(string[] args)
        {
            // Load initial data
            BookManager.bookList = File.ReadBooksFromFile(bookFilePath);
            BookManager.borowedList = File.ReadBorrowedBooksFromFile(borrowbookFilePath);
            UserManager.Users = File.ReadUsersFromFile(userFilePath);

            // Rest of your main method...
            BookManager bookManager = new BookManager();
            UserManager userManager = new UserManager();
            Menu menu = new Menu(bookManager, userManager);
            menu.DisplayMainMenu();
        }

    }
} 