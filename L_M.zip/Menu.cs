﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary_1
{
    internal class Menu
    {
        private BookManager bookManager;
        private UserManager userManager;
        public Menu(BookManager bookManager, UserManager userManager)
        {
            this.bookManager = bookManager;
            this.userManager = userManager;
        }

        public void DisplayMainMenu()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("-------------------------------------------------------------------------\n");
                Console.WriteLine("Please enter a section for administration : ");
                Console.WriteLine("(1)   Manage Book.");
                Console.WriteLine("(2)   Manage User.");
                Console.WriteLine("(3)   Exit");
                Console.Write("\nOption :   ");

                switch (Console.ReadLine())
                {
                    case "1":
                        DisplayBookMenu();
                        break;
                    case "2":
                        DisplayUserMenu();
                        break;
                    case "3":
                        Environment.Exit(0);
                        break;
                    default:
                        ShowErrorMessage("Please enter the correct value ...!");
                        break;
                }
            }
        }

        private void DisplayBookMenu()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("Choose one of the following operation : ");
                Console.WriteLine("(1)  Add Book.");
                Console.WriteLine("(2)  Delete Book.");
                Console.WriteLine("(3)  List Book.");
                Console.WriteLine("(4)  List Borrowed Book.");
                Console.WriteLine("(5)  Search Book With Name.");
                Console.WriteLine("(6)  Search Book With ID.");
                Console.WriteLine("(0)  Back to menu.");
                Console.Write("\n Option :   ");

                switch (Console.ReadLine())
                {
                    case "1":
                        Console.Clear();
                        ErorrProvider("book", bookManager.InsertBook(Manager.IpuntBook()), "Added");
                        File.WriteBooksToFile(Program.bookFilePath, BookManager.bookList);
                        break;
                    case "2":
                        Console.Clear();
                        Console.Write("Please enter the book ID :   ");
                        string n = Console.ReadLine();
                        ErorrProvider("book", bookManager.DeleteBook(n), "Deleted");
                        ErorrProvider("book", userManager.DeleteBorrowedBook(n), "Deleted");
                        File.WriteBooksToFile(Program.borrowbookFilePath, BookManager.borowedList);
                        File.WriteBooksToFile(Program.bookFilePath, BookManager.bookList);
                        File.WriteUsersToFile(Program.userFilePath, UserManager.Users);
                        break;
                    case "3":
                        Console.Clear();
                        Manager.GetListAllBook();
                        break;
                    case "4":
                        Console.Clear();
                        Manager.GetListAllBorrowedBook();
                        break;
                    case "5":
                        Console.Clear();
                        Console.Write("Please enter the book name :   ");
                        string bookName = Console.ReadLine();
                        Manager.GetListSearchBook(bookManager.SearchBookWithBookName(bookName));
                        break;
                    case "6":
                        Console.Clear();
                        Console.Write("Please enter the book ID :    ");
                        string bookId = Console.ReadLine();
                        Manager.GetListSearchBook(bookManager.SearchBookWithBookID(bookId));
                        break;
                    case "0":
                        return;
                    default:
                        ShowErrorMessage("Please enter the correct value ...!");
                        break;
                }
            }
        }

        private void DisplayUserMenu()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("Choose one of the following operation : ");
                Console.WriteLine("(1)   Add User.");
                Console.WriteLine("(2)   Delete User.");
                Console.WriteLine("(3)   List User.");
                Console.WriteLine("(4)   Search User With Name.");
                Console.WriteLine("(5)   Search User With ID.");
                Console.WriteLine("(6)   Borrow and Retunr Book for User.");
                Console.WriteLine("(0)   Back to menu.");
                Console.Write("\n-----NUmber-----> ");

                switch (Console.ReadLine())
                {
                    case "1":
                        ErorrProvider("user", userManager.InsertUser(Manager.IpnutUser()), "Added");
                        File.WriteUsersToFile(Program.userFilePath, UserManager.Users);
                        break;
                    case "2":
                        Console.Write("Please enter the user ID :    ");
                        string uID = Console.ReadLine();
                        ErorrProvider("user", userManager.DeleteUser(uID), "Deleted");
                        File.WriteUsersToFile(Program.userFilePath, UserManager.Users);
                        break;
                    case "3":
                        Console.Clear();
                        Manager.GetListAllUser();
                        break;
                    case "4":
                        Console.Clear();
                        Console.Write("Please enter the user name :    ");
                        string nameUser = Console.ReadLine();
                        Manager.GetListSearchUser(userManager.SearchUserWithNameUser(nameUser));
                        break;
                    case "5":
                        Console.Clear();
                        Console.Write("Please enter the user ID :   ");
                        string IDUser = Console.ReadLine();
                        Manager.GetListSearchUser(userManager.SearchUserWithUserID(IDUser));
                        break;
                    case "6":
                        Console.Clear();
                        Console.WriteLine("Enter User ID: ");
                        string userID = Console.ReadLine();
                        var user = UserManager.Users.FirstOrDefault(u => u._id == userID);
                        if(user != null)
                        {
                            DisplayUserBorrowReturnMenu(user);
                        }
                        else
                        {
                            Console.WriteLine("User not found!");
                        }
                        break;
                    case "0":
                        return;
                    default:
                        ShowErrorMessage("Please enter the correct value ...!");
                        break;
                }
            }
        }

        private void DisplayUserBorrowReturnMenu(User user)
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine($"User: {user._name} (ID: {user._id})");
                Console.WriteLine("Choose an operation:");
                Console.WriteLine("(1) Borrow a Book");
                Console.WriteLine("(2) Return a Book");
                Console.WriteLine("(3) Book list");
                Console.WriteLine("(0) Back to User Menu");
                Console.Write("\nOption: ");

                switch (Console.ReadLine())
                {
                    case "1":
                        if (!string.IsNullOrEmpty(user._borrowedBooksID))
                        {
                            Console.WriteLine("You have already borrowed a book.");
                            Console.ReadKey();
                            break;
                        }
                        Console.Write("Enter Book ID to borrow: ");
                        string bookID = Console.ReadLine();
                        ErorrProvider("book", userManager.BorrowBook(user._id, bookID), "Borrowed");
                        File.WriteBooksToFile(Program.bookFilePath, BookManager.bookList);
                        File.WriteBooksToFile(Program.borrowbookFilePath, BookManager.borowedList);
                        File.WriteUsersToFile(Program.userFilePath, UserManager.Users);
                        Console.ReadKey();
                        break;

                    case "2":
                        if (string.IsNullOrEmpty(user._borrowedBooksID))
                        {
                            Console.WriteLine("You have no book to return.");
                            Console.ReadKey();
                            break;
                        }
                        ErorrProvider("book", userManager.ReturnBook(user._id), "Returned");
                        File.WriteBooksToFile(Program.bookFilePath, BookManager.bookList);
                        File.WriteBooksToFile(Program.borrowbookFilePath, BookManager.borowedList);
                        File.WriteUsersToFile(Program.userFilePath, UserManager.Users);
                        Console.ReadKey();
                        break;
                    case "3":
                        Console.Clear();
                        Manager.GetListAllBook();
                        break;
                    case "0":
                        return;

                    default:
                        ShowErrorMessage("Please enter the correct value ...!");
                        break;
                }
            }
        }
        private void ErorrProvider(string name, bool isValid, string operation)
        {

                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine($"@ The {name} has been successfully {operation} @");
                Console.ResetColor();
                Console.ReadKey();

        }

        private void ShowErrorMessage(string message)
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(message);
            Console.ResetColor();
            Console.ReadKey();
        }
    }

}
