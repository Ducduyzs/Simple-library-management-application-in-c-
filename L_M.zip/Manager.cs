﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace MyLibrary_1
{
    internal static class Manager
    {

        public static Book IpuntBook()
        {
            Book b = new Book("", "", "", true, "", "");
            try
            {
                while (true)
                {
                    Console.WriteLine("Enter Book ID : ");
                    string a = Console.ReadLine();
                    if (a != "")
                    {
                        b._id = a;
                        break;
                    }
                }
                while (true)
                {
                    Console.WriteLine("Enter Book Name : ");
                    string a = Console.ReadLine();
                    if (a != "")
                    {
                        b._name = a; break;
                    }
                }
                Console.WriteLine("Enter Writer : ");
                b._writer = Console.ReadLine();
                Console.WriteLine("Enter Issue : ");
                b._issue = Console.ReadLine();
                Console.WriteLine("Enter Group : ");
                b._grouping = Console.ReadLine();
                b._isAvailable = true;
                return b;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Please enter the correct value ...!");
                Console.ResetColor();
                return null;
            }

        }

        // Show List Books
        public static void GetListAllBook()
        {
            try
            {
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine("\nList Books : \n");
                foreach (var i in BookManager.bookList)
                {
                    Console.WriteLine($"Book ID : {i._id}");
                    Console.WriteLine($"Book Name : {i._name}");
                    Console.WriteLine($"Book Writer : {i._writer}");
                    Console.WriteLine($"Book Issue : {i._issue}");
                    Console.WriteLine($"Book Group : {i._grouping}");
                    Console.WriteLine($"IsAvailable : {i._isAvailable}");
                    Console.WriteLine("*******************************************");
                }
                Console.ReadKey();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                Console.ResetColor();
            }

        }

        // Show List Borrowed 
        public static void GetListAllBorrowedBook()
        {
            try
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\nList of Borrowed Books:\n");

                foreach (var book in BookManager.borowedList)
                {
                    var borrower = UserManager.Users.FirstOrDefault(user => user._borrowedBooksID == book._id);
                    string userID = borrower != null ? borrower._id : "Unknown";
                    Console.WriteLine($"Book ID      : {book._id}");
                    Console.WriteLine($"Book Name    : {book._name}");
                    Console.WriteLine($"Book Writer  : {book._writer}");
                    Console.WriteLine($"Book Issue   : {book._issue}");
                    Console.WriteLine($"Book Group   : {book._grouping}");
                    Console.WriteLine($"Is Available : {book._isAvailable}");
                    Console.WriteLine($"User ID Borrow: {userID}");
                    Console.WriteLine("*******************************************");
                }
                Console.ReadKey();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
            finally
            {
                Console.ResetColor();
            }
        }


        // Get User Details
        public static User IpnutUser()
        {
            User b = new User("", "", "", "");
            try
            {
                while (true)
                {
                    Console.WriteLine("Enter ID : ");
                    string a = Console.ReadLine();
                    if (a != "")
                    {
                        b._id = a;
                        break;
                    }
                }
                while (true)
                {
                    Console.WriteLine("Enter Name : ");
                    string a = Console.ReadLine();
                    if (a != "")
                    {
                        b._name = a; break;
                    }
                }
                Console.WriteLine("Enter Email : ");
                b._email = Console.ReadLine();
                return b;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Please enter the correct value ...!");
                Console.ResetColor();

                return null;
            }
        }

        // Show List User
        public static void GetListAllUser()
        {
            try
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.DarkGreen;
                Console.WriteLine("\nList Users : \n");
                foreach (var i in UserManager.Users)
                {
                    Console.WriteLine($"User ID : {i._id}");
                    Console.WriteLine($"User Name : {i._name}");
                    Console.WriteLine($"User Email : {i._email}");
                    Console.WriteLine($"Book Borrowed : {i._borrowedBooksID}");
                    Console.WriteLine("*******************************************");
                }
                Console.ReadKey();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                Console.ResetColor();
            }
        }

        // Show Result Search Book
        public static void GetListSearchBook(List<Book> bookList)
        {
            try
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine("\nResult Search : \n");
                foreach (var i in bookList)
                {
                    Console.WriteLine($"Book Id : {i._id}");
                    Console.WriteLine($"Book Name : {i._name}");
                    Console.WriteLine($"Book Writer : {i._writer}");
                    Console.WriteLine($"Book Issue : {i._issue}");
                    Console.WriteLine($"Book Group : {i._grouping}");
                    Console.WriteLine($"IsAvailable : {i._isAvailable}");
                    Console.WriteLine("*******************************************");
                }
                Console.ReadKey();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                Console.ResetColor();
            }
        }

        // Show Result Search User
        public static void GetListSearchUser(List<User> userList)
        {
            try
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.DarkMagenta;
                Console.WriteLine("\nSearch Result : \n");
                foreach (var i in userList)
                {
                    Console.WriteLine($"User ID : {i._id}");
                    Console.WriteLine($"User Name : {i._name}");
                    Console.WriteLine($"User Email : {i._email}");
                    Console.WriteLine($"Book Borrowed : {i._borrowedBooksID}");

                    Console.WriteLine("*********************************************");
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                Console.ResetColor();
            }
        }
    }
}
