﻿using System;
using System.Collections.Generic;

namespace MyLibrary_1
{
    internal class Book
    {
        private string id;
        private string name;
        private string writer;
        private bool isAvailable;
        private string issue;
        private string grouping;

        public string _id
        {
            get { return id; }
            set { id = value; }
        }
        public string _name
        {
            get { return name; }
            set { name = value; } 
        }
        public string _writer
        { 
            get { return writer; }
            set { writer = value; } 
        }
        public bool _isAvailable
        {
            get { return isAvailable; }
            set { isAvailable = value; } 
        }
        public string _issue
        {
            get { return issue; }
            set { issue = value; }
        }
        public string _grouping
        {
            get { return grouping; }
            set { grouping = value; }
        }



        public Book(string id, string name, string writer, bool isAvailable, string issue, string grouping)
        {
            this._id = id;
            this._name = name;
            this._writer = writer;
            this._isAvailable = isAvailable;
            this._issue = issue;
            this._grouping = grouping;
        }
    }
}
