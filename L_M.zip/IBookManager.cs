﻿using System;
using System.Collections.Generic;


namespace MyLibrary_1
{
    internal interface IBookManager
    {
        // Add Book
        bool InsertBook(Book book);
        // Delete Book
        bool DeleteBook(string bookID);

        // Search Book With IDber Book
        List<Book> SearchBookWithBookID(string bookID);

        // Search Book With Book Name
        List<Book> SearchBookWithBookName(string bookName);
    }
}
