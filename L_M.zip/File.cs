﻿using System;
using System.Collections.Generic;
using System.IO;

namespace MyLibrary_1
{
    internal static class File
    {
        // Read books from file
        public static List<Book> ReadBooksFromFile(string filePath)
        {
            List<Book> books = new List<Book>();
            if (!System.IO.File.Exists(filePath))
            {
                Console.WriteLine($"File not found: {filePath}");
                return books;
            }

            try
            {
                string[] lines = System.IO.File.ReadAllLines(filePath);

                foreach (string line in lines)
                {
                    string[] parts = line.Split(',');

                    if (parts.Length == 6)
                    {
                        string id = parts[0].Trim();
                        string name = parts[1].Trim();
                        string writer = parts[2].Trim();

                        bool isAvailable;
                        if (!bool.TryParse(parts[3].Trim(), out isAvailable))
                        {
                            isAvailable = true;
                        }

                        string issue = parts[4].Trim();
                        string grouping = parts[5].Trim();

                        Book book = new Book(id, name, writer, isAvailable, issue, grouping);
                        books.Add(book);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error reading books file: {ex.Message}");
            }

            return books;
        }

        // Read borrowed books from file
        public static List<Book> ReadBorrowedBooksFromFile(string filePath)
        {
            List<Book> borrowedBooks = new List<Book>();
            if (!System.IO.File.Exists(filePath))
            {
                Console.WriteLine($"File not found: {filePath}");
                return borrowedBooks;
            }

            try
            {
                string[] lines = System.IO.File.ReadAllLines(filePath);

                foreach (string line in lines)
                {
                    string[] parts = line.Split(',');

                    if (parts.Length == 6)
                    {
                        string id = parts[0].Trim();
                        string name = parts[1].Trim();
                        string writer = parts[2].Trim();

                        bool isAvailable;
                        if (!bool.TryParse(parts[3].Trim(), out isAvailable))
                        {
                            isAvailable = false;
                        }

                        string issue = parts[4].Trim();
                        string grouping = parts[5].Trim();

                        Book book = new Book(id, name, writer, isAvailable, issue, grouping);
                        borrowedBooks.Add(book);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error reading borrowed books file: {ex.Message}");
            }

            return borrowedBooks;
        }

        // Read users from file
        public static List<User> ReadUsersFromFile(string filePath)
        {
            List<User> users = new List<User>();

            if (!System.IO.File.Exists(filePath))
            {
                Console.WriteLine($"File not found: {filePath}");
                return users;
            }

            try
            {
                string[] lines = System.IO.File.ReadAllLines(filePath);

                foreach (string line in lines)
                {
                    string[] parts = line.Split(',');

                    if (parts.Length == 4)
                    {
                        string id = parts[0].Trim();
                        string name = parts[1].Trim();
                        string email = parts[2].Trim();
                        string borrowedBooksID = parts[3].Trim();

                        User user = new User(id, name, email, borrowedBooksID);
                        users.Add(user);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error reading users file: {ex.Message}");
            }

            return users;
        }

        // Write books to file
        public static void WriteBooksToFile(string filePath, List<Book> books)
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(filePath));

                using (StreamWriter writer = new StreamWriter(filePath, false))
                {
                    foreach (var book in books)
                    {
                        string line = $"{book._id},{book._name},{book._writer},{book._isAvailable},{book._issue},{book._grouping}";
                        writer.WriteLine(line);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error writing books to file: {ex.Message}");
            }
        }

        // Write users to file
        public static void WriteUsersToFile(string filePath, List<User> users)
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(filePath));

                using (StreamWriter writer = new StreamWriter(filePath, false))
                {
                    foreach (var user in users)
                    {
                        string line = $"{user._id},{user._name},{user._email},{user._borrowedBooksID}";
                        writer.WriteLine(line);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error writing users to file: {ex.Message}");
            }
        }
    }
}